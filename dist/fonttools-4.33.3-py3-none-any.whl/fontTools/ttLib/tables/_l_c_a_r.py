from .otBase import BaseTTXConverter


class table__l_c_a_r(BaseTTXConverter):
	pass
